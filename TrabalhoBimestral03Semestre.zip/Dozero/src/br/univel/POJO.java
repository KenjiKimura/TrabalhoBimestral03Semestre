package br.univel;

import java.lang.reflect.Method;

public class POJO {
	
	public POJO() {
		
		Devedor devedor = new Devedor();
		
		mostrarNomesDosMetodos(devedor);
		
		
	}
	
	private void mostrarNomesDosMetodos(Object obj) {
		

		Class<?> cl = obj.getClass();

		Method[] vetorMetodos = cl.getDeclaredMethods();

		for (Method method : vetorMetodos) {
			System.out.println("public" + " " + method.getReturnType().getSimpleName() + " " +  method.getName() + " {" + "\n" + "\n" + " }");
		}

	}
	
	public static void main(String[] args) {
		new POJO();
	}
}
