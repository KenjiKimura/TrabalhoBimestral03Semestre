package br.univel;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
	
	public static Connection conectaNoBanco(){
		String usuario = "postgres";
		String senha = "postgres";
		Connection con = null;
		
		try {
			Class.forName("org.postgresql.Driver");
			con = (Connection)DriverManager.getConnection("jdbc:postgresql://localhost:5432/devedor", usuario, senha);
			System.out.println("Conex�o realizada com sucesso");
			return con;
			
		} catch (ClassNotFoundException ex) {
			System.out.println(ex.getMessage());
			return con;
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			return con;
		}
	}
}
