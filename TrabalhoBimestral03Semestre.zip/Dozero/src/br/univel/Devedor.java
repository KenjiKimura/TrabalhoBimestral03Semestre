package br.univel;

import java.io.Serializable;
import java.math.BigDecimal;
public class Devedor implements Serializable{
	
	private Integer devedor_id;
	private String nome;
	private Integer cpf;
	private BigDecimal valor;
	public Integer getDevedor_id() {
		return devedor_id;
	}
	public void setDevedor_id(Integer devedor_id) {
		this.devedor_id = devedor_id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public Integer getCpf() {
		return cpf;
	}
	public void setCpf(Integer cpf) {
		this.cpf = cpf;
	}
	public BigDecimal getValor() {
		return valor;
	}
	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

}
