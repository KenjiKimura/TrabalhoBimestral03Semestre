package br.univel;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;

public class Frame extends JFrame {

	private JPanel contentPane;
	private JTextField tfNome;
	private JTextField tfcpf;
	private JTextField tfValor;
	private JTable table;
	private JButton btnSalvar;
	private JButton btnExcluir;
	private JButton btnBuscar;
	
	private static Connection con;
	private static PreparedStatement pst;
	private ResultSet resultado;
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame frame = new Frame();
					frame.setVisible(true);
					con = Conexao.conectaNoBanco();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 464, 347);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{1.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNome = new JLabel("Nome");
		GridBagConstraints gbc_lblNome = new GridBagConstraints();
		gbc_lblNome.insets = new Insets(0, 0, 5, 5);
		gbc_lblNome.gridx = 0;
		gbc_lblNome.gridy = 0;
		contentPane.add(lblNome, gbc_lblNome);
		
		JLabel lblCpf = new JLabel("CPF");
		GridBagConstraints gbc_lblCpf = new GridBagConstraints();
		gbc_lblCpf.insets = new Insets(0, 0, 5, 5);
		gbc_lblCpf.gridx = 5;
		gbc_lblCpf.gridy = 0;
		contentPane.add(lblCpf, gbc_lblCpf);
		
		JLabel lblValor = new JLabel("Valor");
		GridBagConstraints gbc_lblValor = new GridBagConstraints();
		gbc_lblValor.insets = new Insets(0, 0, 5, 0);
		gbc_lblValor.gridx = 10;
		gbc_lblValor.gridy = 0;
		contentPane.add(lblValor, gbc_lblValor);
		
		tfNome = new JTextField();
		GridBagConstraints gbc_textField = new GridBagConstraints();
		gbc_textField.insets = new Insets(0, 0, 5, 5);
		gbc_textField.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField.gridx = 0;
		gbc_textField.gridy = 1;
		contentPane.add(tfNome, gbc_textField);
		tfNome.setColumns(10);
		
		tfcpf = new JTextField();
		GridBagConstraints gbc_textField_1 = new GridBagConstraints();
		gbc_textField_1.insets = new Insets(0, 0, 5, 5);
		gbc_textField_1.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_1.gridx = 5;
		gbc_textField_1.gridy = 1;
		contentPane.add(tfcpf, gbc_textField_1);
		tfcpf.setColumns(10);
		
		tfValor = new JTextField();
		GridBagConstraints gbc_textField_2 = new GridBagConstraints();
		gbc_textField_2.insets = new Insets(0, 0, 5, 0);
		gbc_textField_2.fill = GridBagConstraints.HORIZONTAL;
		gbc_textField_2.gridx = 10;
		gbc_textField_2.gridy = 1;
		contentPane.add(tfValor, gbc_textField_2);
		tfValor.setColumns(10);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
				{null, null, null, null},
			},
			new String[] {
				"New column", "New column", "New column", "New column"
			}
		));
		GridBagConstraints gbc_table = new GridBagConstraints();
		gbc_table.insets = new Insets(0, 0, 5, 0);
		gbc_table.gridwidth = 11;
		gbc_table.fill = GridBagConstraints.BOTH;
		gbc_table.gridx = 0;
		gbc_table.gridy = 3;
		contentPane.add(table, gbc_table);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Devedor devedor = new Devedor();
				devedor.setNome(tfNome.getText());
				devedor.setCpf(Integer.valueOf(tfcpf.getText()));
				devedor.setValor(new BigDecimal(tfValor.getText()));
				salvar(devedor);
			}
		});
		GridBagConstraints gbc_btnSalvar = new GridBagConstraints();
		gbc_btnSalvar.insets = new Insets(0, 0, 0, 5);
		gbc_btnSalvar.gridx = 0;
		gbc_btnSalvar.gridy = 4;
		contentPane.add(btnSalvar, gbc_btnSalvar);
		
		btnExcluir = new JButton("Excluir");
		btnExcluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Object valorDaCelulaId = table.getModel().getValueAt(table.getSelectedRow(), table.getSelectedColumn());
				excluir(new Integer((int)valorDaCelulaId));
				
			}

			
		});
		GridBagConstraints gbc_btnExcluir = new GridBagConstraints();
		gbc_btnExcluir.insets = new Insets(0, 0, 0, 5);
		gbc_btnExcluir.gridx = 5;
		gbc_btnExcluir.gridy = 4;
		contentPane.add(btnExcluir, gbc_btnExcluir);
		
		btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				buscarTodos();
				
			}
		});
		GridBagConstraints gbc_btnBuscar = new GridBagConstraints();
		gbc_btnBuscar.gridx = 10;
		gbc_btnBuscar.gridy = 4;
		contentPane.add(btnBuscar, gbc_btnBuscar);
	}
	
	public void salvar(Devedor devedor){
		String sql = "INSERT INTO devedor VALUES (?, ?, ?, ?)";
		
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, 1);
			pst.setString(2, devedor.getNome());
			pst.setInt(3, devedor.getCpf());
			pst.setObject(4, devedor.getValor());
			
			pst.execute();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	public void buscarTodos(){
		String sql = "SELECT * FROM devedor";
		
		try {
			pst = con.prepareStatement(sql);
			
			resultado = pst.executeQuery();
			while(resultado.next()){
				List<Devedor> lista = new ArrayList<>();
				Devedor devedor = new Devedor();
				devedor.setDevedor_id(resultado.getInt("devedor_id"));
				devedor.setNome(resultado.getString("nome"));
				devedor.setCpf(resultado.getInt("cpf"));
				devedor.setValor(resultado.getBigDecimal("valor"));
				
				lista.add(devedor);
				
				DevedorTableModel modelo = new DevedorTableModel(lista);
				table.setModel(modelo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	
	private void excluir(Integer devedor_id) {
		String sql = "DELETE FROM devedor WHERE devedor_id = ?";
		try {
			pst = con.prepareStatement(sql);
			pst.setInt(1, devedor_id);
			pst.execute();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}

}
